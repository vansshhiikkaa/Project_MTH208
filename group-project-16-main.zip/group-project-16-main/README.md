# Project Repository

This repository will contain **ALL** the code, analysis, document and presentation for your group project.

This repository contains five folders namely,

Codes: contains all our codes for scrapping of data.

Data: contains all R.data files which we got from web scrapping.

Presentation: contains our powerpoint presentation slides.

Project Report: contains our project report.

Shiny: contains code for our shinyapp.
 

